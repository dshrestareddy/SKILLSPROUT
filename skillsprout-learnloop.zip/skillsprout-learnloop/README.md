# SkillSprout LearnLoop

LearnLoop helps first-year engineering students plan their next four semesters. You tell it your branch, your current semester, how much programming you have done and the career you are aiming at. It builds a roadmap where no course appears before its prerequisites, and then tracks your progress as you enroll and finish modules.

Built for a hackathon. The stack is React, Tailwind, Express and SQLite.

## What is in the box

- **Diagnostic intake**: branch, semester, a short programming self-check, and a career pathway.
- **Roadmap engine**: the course catalogue is a directed acyclic graph. Kahn's algorithm orders it and detects cycles, and a scheduler then packs the courses into four semesters under a credit cap.
- **Interactive roadmap**: courses are colour coded as completed, in progress, unlocked or locked. Prerequisites show on every card, and module toggles live right on the card.
- **Catalog**: 48 courses with search by code or title, plus credit, difficulty and area filters.
- **Enrollment**: the server refuses to enroll you in a course whose prerequisites are not finished, and says which ones.
- **Progress**: course progress is modules done out of four. Semester and overall percentages are credit-weighted. Everything is stored in SQLite, and the last snapshot is cached in localStorage so a refresh paints instantly.
- **Extras**: weekly study-hours estimator, peer study group recommendations, PDF export of the roadmap, and an SVG prerequisite graph with a "would this create a loop?" checker.

## Setup

You need Node.js 18 or newer (20 or 22 recommended).

```bash
npm run setup          # installs server and client dependencies
npm run dev:server     # terminal 1: API on http://localhost:4000
npm run dev:client     # terminal 2: UI on http://localhost:5173
```

Open http://localhost:5173. The SQLite database is created and seeded on the first server start (`server/data/learnloop.db`).

For a single-process demo:

```bash
npm run build          # builds the React app into client/dist
npm start              # the API server now also serves the UI on :4000
```

Run the backend workflow test with `npm test`. It starts the server, walks through the demo scenario over HTTP, restarts the server and checks that progress survived.

## Demo script (about three minutes)

1. Open the app and click **Use the demo student**. This signs in Aarav, a first-year CSE student.
2. In the diagnostic, choose **CSE**, **semester 1**, tick one or two programming statements, and pick **Full-Stack Web**.
3. Click **Generate my roadmap**. Point out the four semesters, the prerequisite pills and the locked cards.
4. Try to enroll in something locked (open **CS102**). The drawer shows it is locked until CS101 is finished.
5. On the roadmap, click **Enroll** on **CS101**.
6. Open **My courses** and click **Module 1** on CS101.
7. The CS101 progress bar and percentage jump to **25%**. The dashboard shows the same number under Continue learning, and the weekly study-hours card fills in.
8. Refresh the browser. Progress is still there, because it lives in SQLite and not only in the page. You can also stop and restart the server to show it survives that too.
9. Optional extras: finish all four modules to watch CS102 unlock, open **Dependency graph** and click a course, try the loop checker (CS101 with CS201 as its prerequisite), and export the PDF.

To rerun the demo from scratch, use **Reset progress** in the sidebar, or delete `server/data/learnloop.db` and restart the server.

## How the roadmap is built

1. The pathway decides the must-have courses, plus every prerequisite they depend on.
2. The branch adds its core courses. These are optional: if four semesters cannot hold everything, the highest-level ones are dropped first, so a course never disappears before something that depends on it.
3. Kahn's algorithm orders the chosen courses. Among courses that are ready at the same time, the ones with the longest chain of dependents go first, so deep chains start early.
4. Courses are placed in order into the first semester that is after all their prerequisites and still under the credit cap (20, 21, 22 or 24 credits depending on programming experience).
5. Courses already completed are left out, so regenerating the roadmap after some progress gives a shorter plan.

The cycle checker runs at server start (the server refuses to boot on a circular catalogue) and on demand from the graph page.

The weekly study-hours estimate is a rule-based formula: credits times a difficulty factor, nudged by programming experience for coding-heavy courses. It does not call an external AI model.

## Project layout

```
server/
  index.js          Express setup and error handling
  routes.js         REST endpoints
  db.js             SQLite schema, seeding, startup graph check
  data/courses.js   catalogue, branches, pathways, study groups
  lib/graph.js      Kahn's sort, cycle detection, edge check
  lib/roadmap.js    semester packing
  lib/service.js    business rules (enrollment, progress, groups, estimates)
  test/             end-to-end workflow test
client/
  src/store.jsx     app state, localStorage cache, API actions
  src/pages/        Login, Diagnostic, Dashboard, Roadmap, Catalog, MyCourses, GraphView, Groups
  src/components/   Layout, CourseDrawer, ProgressRing, ModuleChecks, StatusBadge
  src/lib/pdf.js    roadmap PDF export
```

## API

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/auth/login` | sign in or create a student by name and email |
| GET | `/api/students/:id/state` | full snapshot: course states, roadmap, stats, recommendations |
| PUT | `/api/students/:id/profile` | save the diagnostic |
| POST | `/api/students/:id/roadmap` | generate the roadmap |
| POST | `/api/students/:id/enroll` | enroll (checks prerequisites) |
| DELETE | `/api/students/:id/enroll/:courseId` | drop a course |
| PUT | `/api/students/:id/modules` | mark a module done or undone |
| DELETE | `/api/students/:id/progress` | reset progress |
| GET | `/api/students/:id/study-estimate` | weekly hours estimate |
| GET/POST/DELETE | `/api/students/:id/groups...` | recommendations, join, leave |
| GET | `/api/courses` | catalogue with `search`, `credits`, `difficulty`, `category` filters |
| GET | `/api/graph` | nodes, edges and Kahn validation |
| POST | `/api/graph/check-edge` | would this prerequisite create a loop? |

## Known limits

- Sign-in is by name and email with no password. That is fine for a demo and would need real authentication before any real use.
- Course modules are generic (Module 1 to 4) rather than having individual titles.
- Study groups are seeded sample data.
