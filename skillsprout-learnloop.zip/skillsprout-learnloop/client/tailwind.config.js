/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Source Sans 3"', 'system-ui', 'sans-serif'],
        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
      },
      colors: {
        ink: { DEFAULT: '#1B2745', soft: '#2A3860', line: '#36457a' },
        paper: '#F3F5F9',
        sprout: { 50: '#E8F6EF', 100: '#CFEBDD', 500: '#1F9D6B', 600: '#188559', 700: '#126B47' },
        iris: { 50: '#ECEEFC', 100: '#D9DDF8', 500: '#4457D8', 600: '#3745B8', 700: '#2C3892' },
      },
    },
  },
  plugins: [],
};
