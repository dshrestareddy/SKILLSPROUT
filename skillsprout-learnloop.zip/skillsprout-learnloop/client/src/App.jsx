import { Navigate, Route, Routes } from 'react-router-dom';
import { useApp } from './store';
import Layout, { Toast, BrandMark } from './components/Layout';
import Login from './pages/Login';
import Diagnostic from './pages/Diagnostic';
import Dashboard from './pages/Dashboard';
import Roadmap from './pages/Roadmap';
import Catalog from './pages/Catalog';
import MyCourses from './pages/MyCourses';
import GraphView from './pages/GraphView';
import Groups from './pages/Groups';

function Splash() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="flex items-center gap-3 text-ink"><BrandMark size={36} /><span className="font-display text-xl font-bold">Loading LearnLoop</span></div>
    </div>
  );
}

function ServerError() {
  const { bootError, retry } = useApp();
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <div className="card max-w-md p-6 text-center">
        <h1 className="text-xl font-bold">The server is not responding</h1>
        <p className="mt-2 text-slate-600">{bootError}</p>
        <p className="mt-2 text-sm text-slate-500">Start it with <code className="rounded bg-slate-100 px-1.5 py-0.5">npm run dev:server</code> and try again.</p>
        <button type="button" onClick={retry} className="btn-primary mt-4">Try again</button>
      </div>
    </div>
  );
}

export default function App() {
  const { loading, bootError, student } = useApp();

  let screen;
  if (bootError) screen = <ServerError />;
  else if (loading) screen = <Splash />;
  else if (!student) screen = <Login />;
  else if (!student.profileDone) screen = <Diagnostic standalone />;
  else {
    screen = (
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/roadmap" element={<Roadmap />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/my-courses" element={<MyCourses />} />
          <Route path="/graph" element={<GraphView />} />
          <Route path="/groups" element={<Groups />} />
          <Route path="/diagnostic" element={<Diagnostic />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    );
  }

  return (
    <>
      {screen}
      <Toast />
    </>
  );
}
