const BASE = '/api';

async function call(method, url, body) {
  let res;
  try {
    res = await fetch(BASE + url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw Object.assign(new Error('Cannot reach the server. Check that it is running on port 4000.'), { network: true });
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed.'), { status: res.status, data });
  return data;
}

export const api = {
  meta: () => call('GET', '/meta'),
  courses: () => call('GET', '/courses'),
  graph: () => call('GET', '/graph'),
  checkEdge: (course, prereq) => call('POST', '/graph/check-edge', { course, prereq }),
  login: (name, email) => call('POST', '/auth/login', { name, email }),
  state: (id) => call('GET', `/students/${id}/state`),
  profile: (id, body) => call('PUT', `/students/${id}/profile`, body),
  roadmap: (id) => call('POST', `/students/${id}/roadmap`),
  enroll: (id, courseId) => call('POST', `/students/${id}/enroll`, { courseId }),
  drop: (id, courseId) => call('DELETE', `/students/${id}/enroll/${courseId}`),
  module: (id, courseId, moduleNo, done) => call('PUT', `/students/${id}/modules`, { courseId, moduleNo, done }),
  reset: (id) => call('DELETE', `/students/${id}/progress`),
  estimate: (id) => call('GET', `/students/${id}/study-estimate`),
  groups: (id) => call('GET', `/students/${id}/groups`),
  join: (id, gid) => call('POST', `/students/${id}/groups/${gid}/join`),
  leave: (id, gid) => call('DELETE', `/students/${id}/groups/${gid}/join`),
};
