import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { api } from './api';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

// The server is the source of truth. localStorage keeps the signed-in student
// and the last snapshot, so the page paints instantly after a refresh.
const ID_KEY = 'learnloop.studentId';
const SNAP_KEY = 'learnloop.snapshot';

export function AppProvider({ children }) {
  const [meta, setMeta] = useState(null);
  const [courses, setCourses] = useState([]);
  const [graph, setGraph] = useState(null);
  const [snap, setSnap] = useState(null);
  const [groups, setGroups] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bootError, setBootError] = useState('');
  const [offline, setOffline] = useState(false);
  const [toast, setToast] = useState(null);
  const [drawerId, setDrawerId] = useState(null);
  const toastTimer = useRef();

  const courseMap = useMemo(() => Object.fromEntries(courses.map((c) => [c.id, c])), [courses]);
  const student = snap ? snap.student : null;

  const notify = useCallback((message, type = 'ok') => {
    clearTimeout(toastTimer.current);
    setToast({ message, type, key: Date.now() });
    toastTimer.current = setTimeout(() => setToast(null), 3800);
  }, []);

  const applySnap = useCallback((s) => {
    setSnap(s);
    localStorage.setItem(ID_KEY, String(s.student.id));
    localStorage.setItem(SNAP_KEY, JSON.stringify(s));
  }, []);

  const boot = useCallback(async () => {
    setLoading(true);
    setBootError('');
    try {
      const [m, c, g] = await Promise.all([api.meta(), api.courses(), api.graph()]);
      setMeta(m);
      setCourses(c.courses);
      setGraph(g);
    } catch (err) {
      setBootError(err.message);
      setLoading(false);
      return;
    }
    const id = localStorage.getItem(ID_KEY);
    if (id) {
      try {
        const cached = localStorage.getItem(SNAP_KEY);
        if (cached) setSnap(JSON.parse(cached));
      } catch { /* a broken cache is not worth worrying about */ }
      try {
        applySnap(await api.state(id));
        setOffline(false);
      } catch (err) {
        if (err.status === 404) {
          localStorage.removeItem(ID_KEY);
          localStorage.removeItem(SNAP_KEY);
          setSnap(null);
        } else {
          setOffline(true);
        }
      }
    }
    setLoading(false);
  }, [applySnap]);

  useEffect(() => { boot(); }, [boot]);

  // Run a server action that returns a fresh snapshot.
  const act = useCallback(async (fn, okMessage) => {
    try {
      const s = await fn();
      applySnap(s);
      setOffline(false);
      if (okMessage) notify(okMessage, 'ok');
      return s;
    } catch (err) {
      notify(err.message, 'error');
      return null;
    }
  }, [applySnap, notify]);

  const actions = useMemo(() => ({
    login: (name, email) => act(() => api.login(name, email)),
    logout: () => {
      localStorage.removeItem(ID_KEY);
      localStorage.removeItem(SNAP_KEY);
      setSnap(null);
      setGroups(null);
      setDrawerId(null);
    },
    // onReady runs just before the new snapshot lands, so the caller can
    // navigate while its page is still mounted.
    saveProfileAndRoadmap: async (profile, onReady) => {
      const id = Number(localStorage.getItem(ID_KEY));
      try {
        await api.profile(id, profile);
        const s = await api.roadmap(id);
        if (onReady) onReady();
        applySnap(s);
        setOffline(false);
        notify('Your roadmap is ready.', 'ok');
        return s;
      } catch (err) {
        notify(err.message, 'error');
        return null;
      }
    },
    regenerate: () => act(() => api.roadmap(Number(localStorage.getItem(ID_KEY))), 'Roadmap regenerated from your latest progress.'),
    enroll: (courseId) => act(() => api.enroll(Number(localStorage.getItem(ID_KEY)), courseId), `Enrolled in ${courseId}.`),
    drop: (courseId) => act(() => api.drop(Number(localStorage.getItem(ID_KEY)), courseId), `Dropped ${courseId}.`),
    toggleModule: (courseId, moduleNo, done) => act(() => api.module(Number(localStorage.getItem(ID_KEY)), courseId, moduleNo, done)),
    reset: () => act(() => api.reset(Number(localStorage.getItem(ID_KEY))), 'Progress cleared. Your roadmap is unchanged.'),
    loadGroups: async () => {
      try { setGroups((await api.groups(Number(localStorage.getItem(ID_KEY)))).groups); } catch (err) { notify(err.message, 'error'); }
    },
    joinGroup: async (gid) => {
      try { setGroups((await api.join(Number(localStorage.getItem(ID_KEY)), gid)).groups); notify('You joined the group.'); }
      catch (err) { notify(err.message, 'error'); }
    },
    leaveGroup: async (gid) => {
      try { setGroups((await api.leave(Number(localStorage.getItem(ID_KEY)), gid)).groups); notify('You left the group.'); }
      catch (err) { notify(err.message, 'error'); }
    },
  }), [act, notify]);

  const value = {
    meta, courses, courseMap, graph, snap, student, groups, loading, bootError, offline,
    toast, notify, drawerId, openCourse: setDrawerId, closeCourse: () => setDrawerId(null),
    retry: boot, ...actions,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
