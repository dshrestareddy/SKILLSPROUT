import { useState } from 'react';
import { useApp } from '../store';
import Icon from './Icon';

// Four clickable module toggles. Finishing all four completes the course.
export default function ModuleChecks({ courseId, done, compact = false }) {
  const { toggleModule } = useApp();
  const [busy, setBusy] = useState(false);

  async function flip(n) {
    if (busy) return;
    setBusy(true);
    await toggleModule(courseId, n, !done.includes(n));
    setBusy(false);
  }

  return (
    <div className="flex flex-wrap gap-1.5" role="group" aria-label={`Modules for ${courseId}`}>
      {[1, 2, 3, 4].map((n) => {
        const on = done.includes(n);
        return (
          <button
            key={n} type="button" aria-pressed={on} disabled={busy} onClick={() => flip(n)}
            title={`${on ? 'Undo' : 'Mark'} Module ${n} of ${courseId}`}
            className={`inline-flex items-center justify-center gap-1 rounded-md border text-xs font-semibold transition-colors disabled:opacity-60 ${compact ? 'h-7 w-7' : 'px-2.5 py-1.5'} ${on ? 'border-sprout-500 bg-sprout-500 text-white' : 'border-slate-300 bg-white text-slate-600 hover:border-iris-500 hover:text-iris-600'}`}
          >
            {on && !compact ? <Icon name="check" className="h-3.5 w-3.5" /> : null}
            {compact ? n : `Module ${n}`}
          </button>
        );
      })}
    </div>
  );
}
