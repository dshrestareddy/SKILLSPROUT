import { useEffect, useState } from 'react';
import { useApp } from '../store';
import { DIFFICULTY, nameOf } from '../lib/ui';
import Icon from './Icon';
import StatusBadge from './StatusBadge';
import ModuleChecks from './ModuleChecks';

export default function CourseDrawer() {
  const { drawerId, closeCourse, openCourse, courseMap, snap, meta, enroll, drop } = useApp();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!drawerId) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') closeCourse(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [drawerId, closeCourse]);

  if (!drawerId || !courseMap[drawerId]) return null;
  const c = courseMap[drawerId];
  const st = snap?.courseState[c.id] || { status: 'locked', modulesDone: [], progress: 0, unmet: c.prereqs };

  async function run(fn) {
    setBusy(true);
    await fn();
    setBusy(false);
  }

  return (
    <>
      <div className="fixed inset-0 z-40 bg-ink/40" onClick={closeCourse} aria-hidden="true" />
      <aside role="dialog" aria-modal="true" aria-label={`${c.id} details`} className="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col overflow-y-auto bg-white shadow-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-slate-200 p-5">
          <div>
            <p className="text-sm font-semibold text-iris-600">{c.id}</p>
            <h2 className="mt-0.5 text-xl font-bold leading-snug">{c.title}</h2>
          </div>
          <button type="button" onClick={closeCourse} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100" aria-label="Close details">
            <Icon name="x" />
          </button>
        </div>

        <div className="space-y-6 p-5">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={st.status} />
            <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600">{c.credits} credits</span>
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${DIFFICULTY[c.difficulty]}`}>{c.difficulty}</span>
            <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600">{c.category}</span>
          </div>

          <p className="leading-relaxed text-slate-600">{c.description}</p>

          <section>
            <h3 className="mb-2 text-sm font-bold">Prerequisites</h3>
            {c.prereqs.length === 0 ? (
              <p className="text-sm text-slate-500">None. You can start this one right away.</p>
            ) : (
              <ul className="space-y-1.5">
                {c.prereqs.map((p) => {
                  const ok = snap?.courseState[p]?.status === 'completed';
                  return (
                    <li key={p}>
                      <button type="button" onClick={() => openCourse(p)} className="flex w-full items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-left text-sm hover:bg-slate-50">
                        <Icon name={ok ? 'check' : 'lock'} className={`h-4 w-4 ${ok ? 'text-sprout-600' : 'text-slate-400'}`} />
                        <span className="font-semibold">{p}</span>
                        <span className="truncate text-slate-500">{courseMap[p]?.title}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          {c.unlocks.length > 0 && (
            <section>
              <h3 className="mb-2 text-sm font-bold">Opens up</h3>
              <div className="flex flex-wrap gap-1.5">
                {c.unlocks.map((u) => (
                  <button key={u} type="button" onClick={() => openCourse(u)} className="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-iris-50 hover:text-iris-700">{u}</button>
                ))}
              </div>
            </section>
          )}

          {c.pathways.length > 0 && (
            <section>
              <h3 className="mb-2 text-sm font-bold">Career pathways</h3>
              <p className="text-sm text-slate-600">{c.pathways.map((p) => nameOf(meta?.pathways, p)).join(', ')}</p>
            </section>
          )}

          <section className="rounded-xl bg-paper p-4">
            {st.status === 'unlocked' && (
              <button type="button" disabled={busy} onClick={() => run(() => enroll(c.id))} className="btn-primary w-full">Enroll in {c.id}</button>
            )}
            {st.status === 'locked' && (
              <>
                <button type="button" disabled className="btn-ghost w-full"><Icon name="lock" className="h-4 w-4" />Enrollment locked</button>
                <p className="mt-2 text-sm text-slate-500">Finish {st.unmet.join(', ')} first.</p>
              </>
            )}
            {(st.status === 'enrolled' || st.status === 'completed') && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold">Course progress</span>
                  <span className="font-semibold text-iris-600">{st.progress}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-200">
                  <div className="h-full rounded-full bg-iris-500 transition-all duration-700" style={{ width: `${st.progress}%` }} />
                </div>
                <ModuleChecks courseId={c.id} done={st.modulesDone} />
                {st.status === 'enrolled' && (
                  <button type="button" disabled={busy} onClick={() => run(() => drop(c.id))} className="btn-danger w-full">Drop course</button>
                )}
              </div>
            )}
          </section>
        </div>
      </aside>
    </>
  );
}
