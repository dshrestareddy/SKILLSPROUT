import { useEffect, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useApp } from '../store';
import { initials } from '../lib/ui';
import Icon from './Icon';
import CourseDrawer from './CourseDrawer';

const NAV = [
  { to: '/', label: 'Dashboard', icon: 'home', end: true },
  { to: '/roadmap', label: 'Roadmap', icon: 'map' },
  { to: '/catalog', label: 'Course catalog', icon: 'book' },
  { to: '/my-courses', label: 'My courses', icon: 'layers' },
  { to: '/graph', label: 'Dependency graph', icon: 'graph' },
  { to: '/groups', label: 'Study groups', icon: 'users' },
];

export function BrandMark({ size = 32 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <circle cx="16" cy="16" r="15" fill="#1F9D6B" />
      <path d="M16 24V14" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M16 15c0-4 3-6 7-6 0 4-3 6-7 6zM16 18c0-3-2-5-6-5 0 3 2 5 6 5z" fill="#fff" />
    </svg>
  );
}

function SidebarBody({ onNavigate }) {
  const { student, meta, logout, reset } = useApp();
  const navigate = useNavigate();
  const branch = student?.branch || '';
  const pathway = meta?.pathways.find((p) => p.id === student?.pathway)?.name;

  function confirmReset() {
    if (window.confirm('Clear all enrollments, module progress and study-group memberships? Your roadmap stays.')) reset();
    onNavigate?.();
  }

  return (
    <div className="flex h-full flex-col bg-ink text-slate-200">
      <div className="flex items-center gap-3 px-5 py-5">
        <BrandMark />
        <div className="leading-tight">
          <p className="font-display text-lg font-bold text-white">LearnLoop</p>
          <p className="text-xs text-slate-400">by SkillSprout</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-2" aria-label="Main">
        {NAV.map((item) => (
          <NavLink
            key={item.to} to={item.to} end={item.end} onClick={onNavigate}
            className={({ isActive }) => `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition-colors ${isActive ? 'bg-ink-soft text-white' : 'text-slate-300 hover:bg-ink-soft/60 hover:text-white'}`}
          >
            <Icon name={item.icon} className="h-5 w-5" />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="space-y-3 border-t border-ink-line px-4 py-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-sprout-600 text-sm font-bold text-white">{initials(student?.name)}</span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{student?.name}</p>
            <p className="truncate text-xs text-slate-400">{branch} · Semester {student?.semester}{pathway ? ` · ${pathway}` : ''}</p>
          </div>
        </div>
        <div className="grid gap-1.5 text-sm">
          <button type="button" onClick={() => { navigate('/diagnostic'); onNavigate?.(); }} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left text-slate-300 hover:bg-ink-soft hover:text-white">
            <Icon name="sliders" className="h-4 w-4" />Update diagnostic
          </button>
          <button type="button" onClick={confirmReset} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left text-slate-300 hover:bg-ink-soft hover:text-white">
            <Icon name="refresh" className="h-4 w-4" />Reset progress
          </button>
          <button type="button" onClick={logout} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left text-slate-300 hover:bg-ink-soft hover:text-white">
            <Icon name="logout" className="h-4 w-4" />Sign out
          </button>
        </div>
      </div>
    </div>
  );
}

export function Toast() {
  const { toast } = useApp();
  if (!toast) return null;
  const tone = toast.type === 'error' ? 'bg-rose-600' : 'bg-ink';
  return (
    <div key={toast.key} role="status" aria-live="polite" className={`fixed bottom-4 left-1/2 z-[60] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 rounded-lg px-4 py-3 text-sm font-semibold text-white shadow-lg ${tone}`}>
      {toast.message}
    </div>
  );
}

export default function Layout({ children }) {
  const { offline, retry } = useApp();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => { setOpen(false); }, [location.pathname]);

  return (
    <div className="min-h-screen lg:pl-64">
      <div className="fixed inset-y-0 left-0 z-30 hidden w-64 lg:block"><SidebarBody /></div>

      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 lg:hidden">
        <div className="flex items-center gap-2"><BrandMark size={28} /><span className="font-display text-lg font-bold text-ink">LearnLoop</span></div>
        <button type="button" onClick={() => setOpen(true)} className="rounded-lg p-2 text-slate-700 hover:bg-slate-100" aria-label="Open menu"><Icon name="menu" /></button>
      </header>

      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-ink/50" onClick={() => setOpen(false)} aria-hidden="true" />
          <div className="absolute inset-y-0 left-0 w-72 max-w-[85%]"><SidebarBody onNavigate={() => setOpen(false)} /></div>
        </div>
      )}

      {offline && (
        <div className="bg-amber-100 px-4 py-2 text-center text-sm font-semibold text-amber-800">
          Showing your last saved progress. The server is not reachable right now.{' '}
          <button type="button" onClick={retry} className="underline">Try again</button>
        </div>
      )}

      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      <CourseDrawer />
    </div>
  );
}
