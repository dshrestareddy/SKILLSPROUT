import { useEffect } from 'react';
import { useApp } from '../store';
import { nameOf } from '../lib/ui';

function GroupCard({ g }) {
  const { joinGroup, leaveGroup, openCourse, meta } = useApp();
  return (
    <article className="card flex flex-col p-4">
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-base font-bold leading-snug">{g.name}</h3>
        <button type="button" onClick={() => openCourse(g.courseId)} className="rounded bg-iris-50 px-2 py-0.5 text-xs font-bold text-iris-700 hover:bg-iris-100">{g.courseId}</button>
      </div>
      <p className="mt-2 text-sm text-slate-600">{g.description}</p>
      <dl className="mt-3 space-y-1 text-sm">
        <div className="flex gap-2"><dt className="w-16 text-slate-500">When</dt><dd className="font-semibold">{g.schedule}</dd></div>
        <div className="flex gap-2"><dt className="w-16 text-slate-500">Where</dt><dd className="font-semibold">{g.mode}</dd></div>
        <div className="flex gap-2"><dt className="w-16 text-slate-500">Seats</dt><dd className="font-semibold">{g.members} of {g.seats} taken</dd></div>
        {g.pathway && <div className="flex gap-2"><dt className="w-16 text-slate-500">Track</dt><dd className="font-semibold">{nameOf(meta.pathways, g.pathway)}</dd></div>}
      </dl>
      {g.reasons.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {g.reasons.map((r) => <span key={r} className="rounded-full bg-sprout-50 px-2 py-0.5 text-xs font-semibold text-sprout-700">{r}</span>)}
        </div>
      )}
      <div className="mt-auto pt-4">
        {g.joined
          ? <button type="button" className="btn-ghost w-full" onClick={() => leaveGroup(g.id)}>Leave group</button>
          : <button type="button" className="btn-primary w-full" disabled={g.full} onClick={() => joinGroup(g.id)}>{g.full ? 'Group is full' : 'Join group'}</button>}
      </div>
    </article>
  );
}

export default function Groups() {
  const { groups, loadGroups } = useApp();
  useEffect(() => { loadGroups(); }, [loadGroups]);

  if (!groups) return <p className="text-slate-500">Loading study groups...</p>;
  const mine = groups.filter((g) => g.joined);
  const suggested = groups.filter((g) => !g.joined && g.score > 0);
  const rest = groups.filter((g) => !g.joined && g.score === 0);

  const Section = ({ title, hint, items }) => items.length === 0 ? null : (
    <section>
      <h2 className="text-lg font-bold">{title}</h2>
      {hint && <p className="mb-3 text-sm text-slate-500">{hint}</p>}
      <div className="mt-3 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{items.map((g) => <GroupCard key={g.id} g={g} />)}</div>
    </section>
  );

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-bold sm:text-3xl">Study groups</h1>
        <p className="mt-1 text-slate-600">Groups are ranked by the courses you are taking, what is next on your roadmap and your career pathway.</p>
      </header>
      <Section title="Your groups" items={mine} />
      <Section title="Recommended for you" hint="Based on your enrollments and roadmap." items={suggested} />
      <Section title="Other groups" items={rest} />
    </div>
  );
}
