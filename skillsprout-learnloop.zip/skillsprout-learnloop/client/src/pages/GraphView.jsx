import { useMemo, useState } from 'react';
import { api } from '../api';
import { useApp } from '../store';
import { STATUS } from '../lib/ui';
import StatusBadge from '../components/StatusBadge';

const W = 150;
const H = 46;
const GAP = 84;
const ROW = 16;
const PAD = 24;
const TINT = { completed: '#E8F6EF', enrolled: '#ECEEFC', unlocked: '#FDF4E1', locked: '#F1F5F9' };

// Columns are the Kahn levels from the server. Inside a column, courses are
// ordered by the average height of their prerequisites to keep lines short.
function layout(nodes, edges) {
  const byLevel = {};
  nodes.forEach((n) => { (byLevel[n.level] = byLevel[n.level] || []).push(n); });
  const levels = Object.keys(byLevel).map(Number).sort((a, b) => a - b);
  const preds = {};
  edges.forEach((e) => { (preds[e.to] = preds[e.to] || []).push(e.from); });

  const pos = {};
  let tallest = 0;
  levels.forEach((lv, col) => {
    const bary = (n) => {
      const ys = (preds[n.id] || []).filter((p) => pos[p]).map((p) => pos[p].y);
      return ys.length ? ys.reduce((a, b) => a + b, 0) / ys.length : 0;
    };
    byLevel[lv].sort((a, b) => bary(a) - bary(b) || (a.category + a.id).localeCompare(b.category + b.id));
    byLevel[lv].forEach((n, row) => { pos[n.id] = { x: PAD + col * (W + GAP), y: PAD + row * (H + ROW) }; });
    tallest = Math.max(tallest, byLevel[lv].length);
  });
  return {
    pos,
    width: PAD * 2 + levels.length * W + Math.max(0, levels.length - 1) * GAP,
    height: PAD * 2 + tallest * (H + ROW) - ROW,
  };
}

function reach(start, adj) {
  const seen = new Set();
  const stack = [start];
  while (stack.length) {
    const id = stack.pop();
    (adj[id] || []).forEach((n) => { if (!seen.has(n)) { seen.add(n); stack.push(n); } });
  }
  return seen;
}

export default function GraphView() {
  const { graph, snap, courses, courseMap, openCourse } = useApp();
  const [scope, setScope] = useState(snap.roadmap ? 'roadmap' : 'all');
  const [focus, setFocus] = useState(null);

  const ids = useMemo(() => {
    if (scope === 'all' || !snap.roadmap) return null;
    return new Set(snap.roadmap.semesters.flatMap((s) => s.courses));
  }, [scope, snap.roadmap]);

  const shown = useMemo(() => {
    const nodes = graph.nodes.filter((n) => !ids || ids.has(n.id));
    const keep = new Set(nodes.map((n) => n.id));
    const edges = graph.edges.filter((e) => keep.has(e.from) && keep.has(e.to));
    return { nodes, edges, ...layout(nodes, edges) };
  }, [graph, ids]);

  const related = useMemo(() => {
    if (!focus) return null;
    const down = {};
    const up = {};
    shown.edges.forEach((e) => {
      (down[e.from] = down[e.from] || []).push(e.to);
      (up[e.to] = up[e.to] || []).push(e.from);
    });
    return new Set([focus, ...reach(focus, down), ...reach(focus, up)]);
  }, [focus, shown.edges]);

  const statusOf = (id) => snap.courseState[id]?.status || 'locked';
  const sorted = useMemo(() => [...courses].sort((a, b) => a.id.localeCompare(b.id)), [courses]);

  // cycle-check lab
  const [target, setTarget] = useState('CS101');
  const [proposed, setProposed] = useState('CS201');
  const [result, setResult] = useState(null);
  const [checking, setChecking] = useState(false);

  async function check() {
    setChecking(true);
    try { setResult(await api.checkEdge(target, proposed)); }
    catch (err) { setResult({ safe: false, cycle: [], message: err.message }); }
    setChecking(false);
  }

  const v = graph.validation;
  const levelCount = Math.max(...graph.nodes.map((n) => n.level));

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold sm:text-3xl">Prerequisite graph</h1>
        <p className="mt-1 text-slate-600">Each arrow points from a prerequisite to the course it unlocks. Select a course to trace everything before and after it.</p>
      </header>

      <div className={`rounded-lg p-3 text-sm font-semibold ${v.hasCycle ? 'bg-rose-50 text-rose-800' : 'bg-sprout-50 text-sprout-800'}`}>
        {v.hasCycle
          ? `Circular dependency found: ${v.cycle.join(' -> ')}`
          : `No circular dependencies. Kahn's algorithm ordered all ${v.courseCount} courses into ${levelCount} levels.`}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-lg border border-slate-300 bg-white p-0.5 text-sm font-semibold" role="group" aria-label="Graph scope">
          {[['roadmap', 'My roadmap'], ['all', 'All courses']].map(([key, label]) => (
            <button
              key={key} type="button" aria-pressed={scope === key} disabled={key === 'roadmap' && !snap.roadmap}
              onClick={() => { setScope(key); setFocus(null); }}
              className={`rounded-md px-3 py-1.5 ${scope === key ? 'bg-ink text-white' : 'text-slate-600 hover:bg-slate-100'} disabled:opacity-40`}
            >{label}</button>
          ))}
        </div>
        <div className="flex flex-wrap gap-4 text-xs font-semibold text-slate-600">
          {Object.entries(STATUS).map(([key, s]) => (
            <span key={key} className="inline-flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-full ${s.dot}`} />{s.label}</span>
          ))}
        </div>
      </div>

      <div className="card overflow-auto p-2" style={{ maxHeight: '70vh' }}>
        <svg width={shown.width} height={shown.height} role="group" aria-label="Course dependency graph">
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#B6BFD0" /></marker>
            <marker id="arrow-hi" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#4457D8" /></marker>
          </defs>

          {shown.edges.map((e) => {
            const a = shown.pos[e.from];
            const b = shown.pos[e.to];
            const hi = related && related.has(e.from) && related.has(e.to);
            const dim = related && !hi;
            const x1 = a.x + W;
            const y1 = a.y + H / 2;
            const x2 = b.x;
            const y2 = b.y + H / 2;
            const mid = (x2 - x1) / 2;
            return (
              <path
                key={`${e.from}-${e.to}`} d={`M${x1} ${y1} C${x1 + mid} ${y1} ${x2 - mid} ${y2} ${x2 - 2} ${y2}`}
                fill="none" stroke={hi ? '#4457D8' : '#B6BFD0'} strokeWidth={hi ? 2 : 1.3}
                opacity={dim ? 0.15 : 1} markerEnd={`url(#${hi ? 'arrow-hi' : 'arrow'})`}
              />
            );
          })}

          {shown.nodes.map((n) => {
            const p = shown.pos[n.id];
            const status = statusOf(n.id);
            const dim = related && !related.has(n.id);
            const title = n.title.length > 21 ? `${n.title.slice(0, 20)}…` : n.title;
            return (
              <g
                key={n.id} transform={`translate(${p.x} ${p.y})`} opacity={dim ? 0.25 : 1}
                style={{ cursor: 'pointer' }} role="button" tabIndex={0}
                aria-label={`${n.id} ${n.title}, ${STATUS[status].label}`}
                onClick={() => setFocus(focus === n.id ? null : n.id)}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setFocus(focus === n.id ? null : n.id); } }}
              >
                <rect width={W} height={H} rx="9" fill={TINT[status]} stroke={STATUS[status].fill} strokeWidth={focus === n.id ? 3 : 1.6} />
                <text x="10" y="19" fontSize="12" fontWeight="700" fill="#1B2745">{n.id}</text>
                <text x="10" y="35" fontSize="10.5" fill="#55607a">{title}</text>
              </g>
            );
          })}
        </svg>
      </div>

      {focus && courseMap[focus] && (
        <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
          <div>
            <p className="text-xs font-bold text-iris-600">{focus}</p>
            <p className="font-semibold text-ink">{courseMap[focus].title}</p>
            <p className="text-sm text-slate-500">Needs {courseMap[focus].prereqs.length || 'no'} course{courseMap[focus].prereqs.length === 1 ? '' : 's'} · opens {courseMap[focus].unlocks.length}</p>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={statusOf(focus)} />
            <button type="button" className="btn-primary" onClick={() => openCourse(focus)}>Open details</button>
            <button type="button" className="btn-ghost" onClick={() => setFocus(null)}>Clear</button>
          </div>
        </div>
      )}

      <section className="card p-5">
        <h2 className="text-lg font-bold">Try a prerequisite change</h2>
        <p className="mt-1 text-sm text-slate-600">Pick a course and a proposed prerequisite. We run the dependency check and tell you whether it would create a loop. Nothing is saved.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
          <div>
            <label htmlFor="lab-course" className="mb-1 block text-sm font-semibold">Course</label>
            <select id="lab-course" className="field" value={target} onChange={(e) => { setTarget(e.target.value); setResult(null); }}>
              {sorted.map((c) => <option key={c.id} value={c.id}>{c.id} {c.title}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="lab-prereq" className="mb-1 block text-sm font-semibold">Proposed prerequisite</label>
            <select id="lab-prereq" className="field" value={proposed} onChange={(e) => { setProposed(e.target.value); setResult(null); }}>
              {sorted.map((c) => <option key={c.id} value={c.id}>{c.id} {c.title}</option>)}
            </select>
          </div>
          <button type="button" className="btn-primary" onClick={check} disabled={checking}>{checking ? 'Checking...' : 'Check for a loop'}</button>
        </div>
        {result && (
          <div role="status" className={`mt-4 rounded-lg p-3 text-sm ${result.safe ? 'bg-sprout-50 text-sprout-800' : 'bg-rose-50 text-rose-800'}`}>
            <p className="font-semibold">{result.message}</p>
            {result.cycle.length > 0 && (
              <p className="mt-2 flex flex-wrap items-center gap-1.5">
                {result.cycle.map((id, i) => (
                  <span key={`${id}-${i}`} className="inline-flex items-center gap-1.5"><span className="rounded bg-white px-2 py-0.5 font-bold">{id}</span>{i < result.cycle.length - 1 && <span aria-hidden="true">then</span>}</span>
                ))}
              </p>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
