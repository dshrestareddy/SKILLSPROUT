import { useState } from 'react';
import { useApp } from '../store';
import { BrandMark } from '../components/Layout';

// A tiny preview of what the product does: courses coloured by status.
function MiniGraph() {
  const nodes = [
    { id: 'CS101', x: 10, y: 80, fill: '#1F9D6B', text: '#fff' },
    { id: 'CS102', x: 130, y: 40, fill: '#4457D8', text: '#fff' },
    { id: 'WD201', x: 130, y: 120, fill: '#D9910A', text: '#fff' },
    { id: 'WD202', x: 250, y: 80, fill: '#475069', text: '#cbd2e4' },
    { id: 'WD301', x: 250, y: 160, fill: '#475069', text: '#cbd2e4' },
  ];
  const edges = [['CS101', 'CS102'], ['CS101', 'WD201'], ['CS102', 'WD202'], ['WD201', 'WD202'], ['WD202', 'WD301']];
  const at = (id) => nodes.find((n) => n.id === id);
  return (
    <svg viewBox="0 0 340 200" className="w-full max-w-sm" role="img" aria-label="Example of courses linked by prerequisites">
      {edges.map(([a, b]) => {
        const p = at(a), q = at(b);
        return <path key={a + b} d={`M${p.x + 76} ${p.y + 16} C${p.x + 105} ${p.y + 16} ${q.x - 30} ${q.y + 16} ${q.x} ${q.y + 16}`} stroke="#6b7ab5" strokeWidth="1.6" fill="none" />;
      })}
      {nodes.map((n) => (
        <g key={n.id}>
          <rect x={n.x} y={n.y} width="76" height="32" rx="8" fill={n.fill} />
          <text x={n.x + 38} y={n.y + 20} textAnchor="middle" fontSize="12" fontWeight="700" fill={n.text}>{n.id}</text>
        </g>
      ))}
    </svg>
  );
}

export default function Login() {
  const { login } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    const n = name.trim();
    const em = email.trim();
    if (n.length < 2) return setError('Enter your name (at least 2 characters).');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setError('Enter a valid email address.');
    setError('');
    setBusy(true);
    await login(n, em);
    setBusy(false);
    return undefined;
  }

  async function demo() {
    setBusy(true);
    await login('Aarav Menon', 'demo@skillsprout.dev');
    setBusy(false);
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <section className="hidden flex-col justify-between bg-ink p-10 text-white lg:flex">
        <div className="flex items-center gap-3"><BrandMark size={36} /><span className="font-display text-xl font-bold">LearnLoop</span></div>
        <div>
          <h1 className="max-w-md text-4xl font-bold leading-tight text-white">Plan four semesters you can actually finish.</h1>
          <p className="mt-4 max-w-md text-slate-300">Tell us your branch, your coding background and where you want to end up. We order your courses so nothing is taken before its prerequisites.</p>
          <div className="mt-10"><MiniGraph /></div>
        </div>
        <p className="text-sm text-slate-400">Completed, in progress, unlocked and locked courses are colour coded everywhere.</p>
      </section>

      <section className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="mb-6 flex items-center gap-2 lg:hidden"><BrandMark /><span className="font-display text-xl font-bold text-ink">LearnLoop</span></div>
          <h2 className="text-2xl font-bold">Sign in</h2>
          <p className="mt-1 text-sm text-slate-600">New here? Entering your details creates your account.</p>

          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            <div>
              <label htmlFor="name" className="mb-1 block text-sm font-semibold">Full name</label>
              <input id="name" className="field" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
            </div>
            <div>
              <label htmlFor="email" className="mb-1 block text-sm font-semibold">College email</label>
              <input id="email" type="email" className="field" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
            </div>
            {error && <p role="alert" className="text-sm font-semibold text-rose-600">{error}</p>}
            <button type="submit" disabled={busy} className="btn-primary w-full">{busy ? 'Signing in...' : 'Sign in'}</button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-slate-400"><span className="h-px flex-1 bg-slate-200" />or<span className="h-px flex-1 bg-slate-200" /></div>
          <button type="button" onClick={demo} disabled={busy} className="btn-ghost w-full">Use the demo student (Aarav, first-year CSE)</button>
        </div>
      </section>
    </div>
  );
}
