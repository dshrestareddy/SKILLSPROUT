import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../store';
import { BrandMark } from '../components/Layout';

const STEPS = ['Branch', 'Semester', 'Experience', 'Pathway'];

const QUIZ = [
  'I have written a loop or a function before',
  'I have built a small project with more than one file',
  'I use Git or GitHub',
  'I solve problems on a coding practice site',
];
const SCORE_TO_LEVEL = ['none', 'beginner', 'intermediate', 'intermediate', 'advanced'];
const LEVEL_NOTE = {
  none: 'Starting from scratch is fine. We will plan a lighter load.',
  beginner: 'You have written some code. A steady load suits you.',
  intermediate: 'You can handle a fuller semester.',
  advanced: 'You are comfortable coding, so the plan carries more credits.',
};

export default function Diagnostic({ standalone = false }) {
  const { student, meta, saveProfileAndRoadmap } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    branch: student?.branch || '',
    semester: student?.semester || 1,
    experience: student?.experience || '',
    pathway: student?.pathway || '',
  });
  const [answers, setAnswers] = useState([false, false, false, false]);
  const [tried, setTried] = useState(false);
  const [busy, setBusy] = useState(false);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const valid = [!!form.branch, form.semester >= 1 && form.semester <= 8, !!form.experience, !!form.pathway];

  function toggleAnswer(i) {
    const next = answers.map((a, idx) => (idx === i ? !a : a));
    setAnswers(next);
    set('experience', SCORE_TO_LEVEL[next.filter(Boolean).length]);
  }

  function next() {
    if (!valid[step]) { setTried(true); return; }
    setTried(false);
    setStep((s) => s + 1);
  }

  async function finish() {
    if (!valid[step]) { setTried(true); return; }
    setBusy(true);
    const result = await saveProfileAndRoadmap(form, () => navigate('/roadmap'));
    if (!result) setBusy(false);
  }

  const optionClass = (on) => `rounded-xl border p-4 text-left transition-colors ${on ? 'border-sprout-500 bg-sprout-50 ring-1 ring-sprout-500' : 'border-slate-200 bg-white hover:border-iris-500'}`;
  const error = tried && !valid[step];

  const body = (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-2xl font-bold">Tell us where you are starting from</h1>
      <p className="mt-1 text-slate-600">Four quick questions. We use them to build a four-semester plan with the prerequisites in the right order.</p>

      <ol className="mt-6 flex gap-2" aria-label="Progress">
        {STEPS.map((label, i) => (
          <li key={label} className="flex-1">
            <div className={`h-1.5 rounded-full ${i <= step ? 'bg-sprout-500' : 'bg-slate-200'}`} />
            <p className={`mt-1.5 text-xs font-semibold ${i === step ? 'text-ink' : 'text-slate-400'}`}>{label}</p>
          </li>
        ))}
      </ol>

      <div className="card mt-6 p-5 sm:p-6">
        {step === 0 && (
          <fieldset>
            <legend className="mb-3 font-display text-lg font-bold text-ink">Which branch are you in?</legend>
            <div className="grid gap-3 sm:grid-cols-2">
              {meta.branches.map((b) => (
                <button key={b.id} type="button" aria-pressed={form.branch === b.id} onClick={() => set('branch', b.id)} className={optionClass(form.branch === b.id)}>
                  <p className="font-bold text-ink">{b.id}</p>
                  <p className="text-sm text-slate-600">{b.name}</p>
                </button>
              ))}
            </div>
          </fieldset>
        )}

        {step === 1 && (
          <fieldset>
            <legend className="mb-1 font-display text-lg font-bold text-ink">Which semester are you in right now?</legend>
            <p className="mb-3 text-sm text-slate-500">First-year students are usually in semester 1 or 2. Your roadmap covers this semester and the next three.</p>
            <div className="flex flex-wrap gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                <button key={n} type="button" aria-pressed={form.semester === n} onClick={() => set('semester', n)} className={`h-12 w-12 rounded-lg border text-lg font-bold ${form.semester === n ? 'border-sprout-500 bg-sprout-500 text-white' : 'border-slate-300 bg-white text-slate-700 hover:border-iris-500'}`}>{n}</button>
              ))}
            </div>
          </fieldset>
        )}

        {step === 2 && (
          <fieldset>
            <legend className="mb-3 font-display text-lg font-bold text-ink">How much programming have you done?</legend>
            <div className="space-y-2">
              {QUIZ.map((q, i) => (
                <label key={q} className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 px-3 py-2.5 text-sm hover:bg-slate-50">
                  <input type="checkbox" className="h-4 w-4 accent-sprout-600" checked={answers[i]} onChange={() => toggleAnswer(i)} />
                  {q}
                </label>
              ))}
            </div>
            <p className="mb-2 mt-5 text-sm font-semibold">Your level (change it if the suggestion is off)</p>
            <div className="grid gap-3 sm:grid-cols-2">
              {meta.experience.map((e) => (
                <button key={e.id} type="button" aria-pressed={form.experience === e.id} onClick={() => set('experience', e.id)} className={optionClass(form.experience === e.id)}>
                  <p className="font-bold text-ink">{e.label}</p>
                  <p className="text-sm text-slate-600">{LEVEL_NOTE[e.id]}</p>
                </button>
              ))}
            </div>
          </fieldset>
        )}

        {step === 3 && (
          <fieldset>
            <legend className="mb-3 font-display text-lg font-bold text-ink">Where do you want to end up?</legend>
            <div className="grid gap-3 sm:grid-cols-2">
              {meta.pathways.map((p) => (
                <button key={p.id} type="button" aria-pressed={form.pathway === p.id} onClick={() => set('pathway', p.id)} className={optionClass(form.pathway === p.id)}>
                  <p className="font-bold text-ink">{p.name}</p>
                  <p className="text-sm text-slate-600">{p.blurb}</p>
                </button>
              ))}
            </div>
          </fieldset>
        )}

        {error && <p role="alert" className="mt-4 text-sm font-semibold text-rose-600">Choose an option to continue.</p>}
      </div>

      <div className="mt-5 flex justify-between">
        <button type="button" className="btn-ghost" disabled={step === 0 || busy} onClick={() => setStep((s) => s - 1)}>Back</button>
        {step < STEPS.length - 1
          ? <button type="button" className="btn-primary" onClick={next}>Continue</button>
          : <button type="button" className="btn-primary" disabled={busy} onClick={finish}>{busy ? 'Building your roadmap...' : 'Generate my roadmap'}</button>}
      </div>
    </div>
  );

  if (!standalone) return body;
  return (
    <div className="min-h-screen px-4 py-8">
      <div className="mx-auto mb-8 flex max-w-3xl items-center gap-2"><BrandMark /><span className="font-display text-xl font-bold text-ink">LearnLoop</span></div>
      {body}
    </div>
  );
}
