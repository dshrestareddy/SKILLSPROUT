import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useApp } from '../store';
import { firstName, nameOf } from '../lib/ui';
import ProgressRing from '../components/ProgressRing';
import ModuleChecks from '../components/ModuleChecks';
import Icon from '../components/Icon';

function Tile({ label, value, hint }) {
  return (
    <div className="card p-4">
      <p className="text-sm text-slate-500">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold text-ink">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

const LEVEL_STYLE = { light: 'bg-sprout-50 text-sprout-700', balanced: 'bg-iris-50 text-iris-700', heavy: 'bg-rose-50 text-rose-700' };

export default function Dashboard() {
  const { snap, student, meta, courseMap, openCourse, enroll, groups, loadGroups, joinGroup } = useApp();
  const [estimate, setEstimate] = useState(null);
  const { stats, roadmap, recommendations, courseState } = snap;

  useEffect(() => {
    let live = true;
    api.estimate(student.id).then((e) => { if (live) setEstimate(e); }).catch(() => {});
    return () => { live = false; };
  }, [student.id, stats.coursesEnrolled, stats.coursesCompleted]);

  useEffect(() => { loadGroups(); }, [loadGroups]);

  const enrolled = Object.entries(courseState).filter(([, v]) => v.status === 'enrolled').map(([id]) => id);
  const topGroups = (groups || []).filter((g) => g.score > 0).slice(0, 2);
  const pathwayName = nameOf(meta.pathways, student.pathway);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold sm:text-3xl">Welcome back, {firstName(student.name)}</h1>
        <p className="mt-1 text-slate-600">{student.branch} · Semester {student.semester} · {pathwayName}</p>
      </header>

      {!roadmap && (
        <div className="card flex flex-wrap items-center justify-between gap-3 border-amber-300 bg-amber-50 p-4">
          <p className="font-semibold text-amber-900">You do not have a roadmap yet.</p>
          <Link to="/diagnostic" className="btn-primary">Build my roadmap</Link>
        </div>
      )}

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="card flex flex-col items-center justify-center p-6 text-center">
          <ProgressRing value={stats.overallPct} size={150} stroke={12}>
            <span className="font-display text-4xl font-bold text-ink">{stats.overallPct}%</span>
            <span className="text-xs text-slate-500">of your roadmap</span>
          </ProgressRing>
          <p className="mt-4 text-sm text-slate-600">{stats.completedCredits} of {stats.plannedCredits || 0} planned credits finished</p>
        </div>

        <div className="card p-5 lg:col-span-2">
          <h2 className="text-lg font-bold">Semester completion</h2>
          {roadmap ? (
            <ul className="mt-4 space-y-3">
              {roadmap.semesters.map((s) => (
                <li key={s.index}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="font-semibold">Semester {s.semesterNo}</span>
                    <span className="text-slate-500">{s.completedCount} of {s.courses.length} courses · {s.pct}%</span>
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-full bg-slate-200">
                    <div className="h-full rounded-full bg-sprout-500 transition-all duration-1000" style={{ width: `${s.pct}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          ) : <p className="mt-3 text-sm text-slate-500">Generate a roadmap to see how each semester is going.</p>}
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        <Tile label="Credits completed" value={stats.completedCredits} hint={`${stats.enrolledCredits} credits in progress`} />
        <Tile label="Courses in progress" value={stats.coursesEnrolled} />
        <Tile label="Courses completed" value={stats.coursesCompleted} />
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold">Continue learning</h2>
            <Link to="/my-courses" className="text-sm font-semibold text-iris-600 hover:underline">All my courses</Link>
          </div>
          {enrolled.length === 0 ? (
            <p className="mt-3 text-sm text-slate-500">You are not enrolled in anything yet. Pick a recommended course below to get started.</p>
          ) : (
            <ul className="mt-4 space-y-4">
              {enrolled.map((id) => (
                <li key={id} className="rounded-lg border border-slate-200 p-3">
                  <div className="flex items-center justify-between gap-3">
                    <button type="button" onClick={() => openCourse(id)} className="text-left">
                      <span className="text-xs font-bold text-iris-600">{id}</span>
                      <span className="block text-sm font-semibold text-ink">{courseMap[id].title}</span>
                    </button>
                    <span className="font-display text-xl font-bold text-iris-600">{courseState[id].progress}%</span>
                  </div>
                  <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-200">
                    <div className="h-full rounded-full bg-iris-500 transition-all duration-700" style={{ width: `${courseState[id].progress}%` }} />
                  </div>
                  <div className="mt-3 flex items-center gap-2"><span className="text-xs text-slate-500">Modules</span><ModuleChecks courseId={id} done={courseState[id].modulesDone} compact /></div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="card p-5">
          <h2 className="flex items-center gap-2 text-lg font-bold"><Icon name="clock" className="h-5 w-5 text-iris-600" />Weekly study hours</h2>
          {estimate && estimate.items.length > 0 ? (
            <>
              <p className="mt-3 font-display text-4xl font-bold text-ink">{estimate.total}<span className="ml-1 text-base font-semibold text-slate-500">hrs a week</span></p>
              <span className={`mt-2 inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${LEVEL_STYLE[estimate.level]}`}>{estimate.level} load</span>
              <p className="mt-3 text-sm text-slate-600">{estimate.advice}</p>
              <ul className="mt-3 space-y-1.5 text-sm">
                {estimate.items.map((i) => (
                  <li key={i.courseId} className="flex justify-between"><span className="font-semibold">{i.courseId}</span><span className="text-slate-500">{i.hours} hrs</span></li>
                ))}
              </ul>
            </>
          ) : <p className="mt-3 text-sm text-slate-500">Enroll in a course and your weekly estimate shows up here. It adjusts for course difficulty and your programming background.</p>}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <h2 className="text-lg font-bold">Recommended next</h2>
          {recommendations.length === 0 ? (
            <p className="mt-3 text-sm text-slate-500">Nothing is unlocked right now. Finish your current courses to open the next ones.</p>
          ) : (
            <ul className="mt-3 divide-y divide-slate-100">
              {recommendations.map((r) => (
                <li key={r.courseId} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <button type="button" onClick={() => openCourse(r.courseId)} className="text-left">
                    <span className="text-xs font-bold text-iris-600">{r.courseId}</span>
                    <span className="block text-sm font-semibold text-ink">{courseMap[r.courseId].title}</span>
                    <span className="block text-xs text-slate-500">{r.reason}</span>
                  </button>
                  <button type="button" className="btn-primary" onClick={() => enroll(r.courseId)}>Enroll</button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold">Study groups for you</h2>
            <Link to="/groups" className="text-sm font-semibold text-iris-600 hover:underline">See all</Link>
          </div>
          {topGroups.length === 0 ? <p className="mt-3 text-sm text-slate-500">Groups matching your courses will appear here.</p> : (
            <ul className="mt-3 space-y-3">
              {topGroups.map((g) => (
                <li key={g.id} className="rounded-lg border border-slate-200 p-3">
                  <p className="text-sm font-semibold text-ink">{g.name}</p>
                  <p className="text-xs text-slate-500">{g.schedule} · {g.members} of {g.seats} seats</p>
                  {g.joined ? <p className="mt-2 text-xs font-semibold text-sprout-700">You are in this group</p>
                    : <button type="button" disabled={g.full} onClick={() => joinGroup(g.id)} className="btn-ghost mt-2 !px-3 !py-1.5">{g.full ? 'Full' : 'Join'}</button>}
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}
