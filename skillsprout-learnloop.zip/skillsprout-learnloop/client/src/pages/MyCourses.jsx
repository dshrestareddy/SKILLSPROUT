import { Link } from 'react-router-dom';
import { useApp } from '../store';
import StatusBadge from '../components/StatusBadge';
import ModuleChecks from '../components/ModuleChecks';

export default function MyCourses() {
  const { snap, courseMap, openCourse, drop } = useApp();
  const entries = Object.entries(snap.courseState);
  const active = entries.filter(([, v]) => v.status === 'enrolled').map(([id]) => id);
  const done = entries.filter(([, v]) => v.status === 'completed').map(([id]) => id);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold sm:text-3xl">My courses</h1>
        <p className="mt-1 text-slate-600">Each course has four modules. Tick them off as you go and the course completes after the fourth.</p>
      </header>

      <section>
        <h2 className="mb-3 text-lg font-bold">In progress</h2>
        {active.length === 0 ? (
          <div className="card p-6 text-center">
            <p className="font-semibold text-ink">You are not enrolled in any course.</p>
            <p className="mt-1 text-sm text-slate-500">Start with a course that is unlocked on your roadmap.</p>
            <Link to="/roadmap" className="btn-primary mt-3">Open my roadmap</Link>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {active.map((id) => {
              const c = courseMap[id];
              const st = snap.courseState[id];
              return (
                <article key={id} className="card p-4">
                  <div className="flex items-start justify-between gap-3">
                    <button type="button" onClick={() => openCourse(id)} className="text-left">
                      <p className="text-xs font-bold text-iris-600">{id}</p>
                      <h3 className="text-base font-bold leading-snug">{c.title}</h3>
                    </button>
                    <StatusBadge status="enrolled" />
                  </div>
                  <div className="mt-4 flex items-center justify-between text-sm">
                    <span className="text-slate-500">{st.modulesDone.length} of 4 modules</span>
                    <span className="font-display text-xl font-bold text-iris-600">{st.progress}%</span>
                  </div>
                  <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-slate-200">
                    <div className="h-full rounded-full bg-iris-500 transition-all duration-700" style={{ width: `${st.progress}%` }} />
                  </div>
                  <div className="mt-4"><ModuleChecks courseId={id} done={st.modulesDone} /></div>
                  <button type="button" onClick={() => drop(id)} className="btn-danger mt-4 !py-1.5">Drop course</button>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <section>
        <h2 className="mb-3 text-lg font-bold">Completed</h2>
        {done.length === 0 ? <p className="text-sm text-slate-500">Finished courses will be listed here.</p> : (
          <ul className="card divide-y divide-slate-100">
            {done.map((id) => (
              <li key={id} className="flex items-center justify-between gap-3 px-4 py-3">
                <button type="button" onClick={() => openCourse(id)} className="text-left">
                  <span className="text-xs font-bold text-iris-600">{id}</span>
                  <span className="block text-sm font-semibold text-ink">{courseMap[id].title}</span>
                </button>
                <span className="flex items-center gap-3"><span className="text-sm text-slate-500">{courseMap[id].credits} credits</span><StatusBadge status="completed" /></span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
