import { useMemo, useState } from 'react';
import { useApp } from '../store';
import { DIFFICULTY } from '../lib/ui';
import StatusBadge from '../components/StatusBadge';
import Icon from '../components/Icon';

export default function Catalog() {
  const { courses, snap, openCourse, enroll } = useApp();
  const [q, setQ] = useState('');
  const [credits, setCredits] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [category, setCategory] = useState('');

  const categories = useMemo(() => [...new Set(courses.map((c) => c.category))].sort(), [courses]);
  const creditOptions = useMemo(() => [...new Set(courses.map((c) => c.credits))].sort((a, b) => a - b), [courses]);

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    return courses.filter((c) =>
      (!term || c.id.toLowerCase().includes(term) || c.title.toLowerCase().includes(term)) &&
      (!credits || c.credits === Number(credits)) &&
      (!difficulty || c.difficulty === difficulty) &&
      (!category || c.category === category));
  }, [courses, q, credits, difficulty, category]);

  const filtered = q || credits || difficulty || category;
  const clear = () => { setQ(''); setCredits(''); setDifficulty(''); setCategory(''); };

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold sm:text-3xl">Course catalog</h1>
        <p className="mt-1 text-slate-600">{courses.length} courses. Search by code or title, then filter by credits, difficulty or area.</p>
      </header>

      <div className="card grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative sm:col-span-2 lg:col-span-1">
          <Icon name="search" className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input aria-label="Search courses" placeholder="Search code or title" className="field !pl-9" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select aria-label="Filter by credits" className="field" value={credits} onChange={(e) => setCredits(e.target.value)}>
          <option value="">Any credits</option>
          {creditOptions.map((n) => <option key={n} value={n}>{n} credits</option>)}
        </select>
        <select aria-label="Filter by difficulty" className="field" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
          <option value="">Any difficulty</option>
          {['Easy', 'Medium', 'Hard'].map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select aria-label="Filter by area" className="field" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All areas</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <p className="text-sm text-slate-500" aria-live="polite">Showing {list.length} of {courses.length} courses</p>

      {list.length === 0 ? (
        <div className="card p-8 text-center">
          <p className="font-semibold text-ink">No course matches those filters.</p>
          <button type="button" className="btn-ghost mt-3" onClick={clear}>Clear filters</button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((c) => {
            const st = snap.courseState[c.id];
            return (
              <article key={c.id} className="card flex flex-col p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs font-bold text-iris-600">{c.id}</p>
                    <h2 className="text-base font-bold leading-snug">{c.title}</h2>
                  </div>
                  <StatusBadge status={st.status} />
                </div>
                <p className="mt-2 line-clamp-2 text-sm text-slate-600">{c.description}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600">{c.credits} credits</span>
                  <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${DIFFICULTY[c.difficulty]}`}>{c.difficulty}</span>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600">{c.category}</span>
                </div>
                <p className="mt-3 text-xs text-slate-500">{c.prereqs.length ? `Needs ${c.prereqs.join(', ')}` : 'No prerequisites'}</p>
                <div className="mt-auto flex gap-2 pt-4">
                  <button type="button" className="btn-ghost flex-1" onClick={() => openCourse(c.id)}>Details</button>
                  {st.status === 'unlocked' && <button type="button" className="btn-primary flex-1" onClick={() => enroll(c.id)}>Enroll</button>}
                  {st.status === 'locked' && <button type="button" disabled title={`Finish ${st.unmet.join(', ')} first`} className="btn-ghost flex-1"><Icon name="lock" className="h-4 w-4" />Locked</button>}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
