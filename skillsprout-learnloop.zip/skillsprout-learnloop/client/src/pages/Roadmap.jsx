import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../store';
import { DIFFICULTY, STATUS, nameOf } from '../lib/ui';
import { exportRoadmapPdf } from '../lib/pdf';
import StatusBadge from '../components/StatusBadge';
import ModuleChecks from '../components/ModuleChecks';
import Icon from '../components/Icon';

function RoadmapCard({ id }) {
  const { courseMap, snap, openCourse, enroll } = useApp();
  const c = courseMap[id];
  const st = snap.courseState[id];
  const [busy, setBusy] = useState(false);

  async function doEnroll() {
    setBusy(true);
    await enroll(id);
    setBusy(false);
  }

  return (
    <div className={`rounded-lg border-2 p-3 transition-shadow hover:shadow-md ${STATUS[st.status].card}`}>
      <button type="button" onClick={() => openCourse(id)} className="block w-full text-left">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-xs font-bold text-iris-600">{id}</p>
            <p className="text-sm font-semibold leading-snug text-ink">{c.title}</p>
          </div>
        </div>
      </button>

      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        <StatusBadge status={st.status} />
        <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600">{c.credits} cr</span>
        <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${DIFFICULTY[c.difficulty]}`}>{c.difficulty}</span>
      </div>

      {c.prereqs.length > 0 && (
        <div className="mt-2 flex flex-wrap items-center gap-1">
          <span className="text-xs text-slate-500">Needs</span>
          {c.prereqs.map((p) => {
            const ok = snap.courseState[p]?.status === 'completed';
            return (
              <span key={p} className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-xs font-semibold ${ok ? 'bg-sprout-50 text-sprout-700' : 'bg-slate-100 text-slate-500'}`}>
                <Icon name={ok ? 'check' : 'lock'} className="h-3 w-3" />{p}
              </span>
            );
          })}
        </div>
      )}

      <div className="mt-3">
        {st.status === 'unlocked' && <button type="button" disabled={busy} onClick={doEnroll} className="btn-primary w-full !py-1.5">Enroll</button>}
        {st.status === 'locked' && <p className="text-xs text-slate-500">Finish {st.unmet.join(', ')} to unlock.</p>}
        {st.status === 'enrolled' && (
          <div>
            <div className="mb-1.5 flex items-center justify-between text-xs"><span className="text-slate-500">Modules</span><span className="font-semibold text-iris-600">{st.progress}%</span></div>
            <ModuleChecks courseId={id} done={st.modulesDone} compact />
          </div>
        )}
        {st.status === 'completed' && <p className="flex items-center gap-1 text-xs font-semibold text-sprout-700"><Icon name="check" className="h-4 w-4" />All modules finished</p>}
      </div>
    </div>
  );
}

export default function Roadmap() {
  const { snap, student, meta, courseMap, regenerate, notify } = useApp();
  const [busy, setBusy] = useState(false);
  const { roadmap, courseState } = snap;

  if (!roadmap) {
    return (
      <div className="card mx-auto max-w-lg p-8 text-center">
        <h1 className="text-xl font-bold">No roadmap yet</h1>
        <p className="mt-2 text-slate-600">Answer the short diagnostic and we will build your four-semester plan.</p>
        <Link to="/diagnostic" className="btn-primary mt-4">Start the diagnostic</Link>
      </div>
    );
  }

  const branchName = nameOf(meta.branches, student.branch);
  const pathwayName = nameOf(meta.pathways, student.pathway);
  const experienceLabel = nameOf(meta.experience.map((e) => ({ id: e.id, name: e.label })), student.experience);

  async function redo() {
    setBusy(true);
    await regenerate();
    setBusy(false);
  }

  function exportPdf() {
    try {
      exportRoadmapPdf({ student, branchName, pathwayName, experienceLabel, roadmap, courseMap, courseState });
    } catch {
      notify('Could not create the PDF. Please try again.', 'error');
    }
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold sm:text-3xl">Your learning roadmap</h1>
          <p className="mt-1 text-slate-600">{branchName} · {pathwayName} · {experienceLabel} background · up to {roadmap.meta.creditCap} credits a semester</p>
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn-ghost" onClick={redo} disabled={busy}><Icon name="refresh" className="h-4 w-4" />{busy ? 'Rebuilding...' : 'Regenerate'}</button>
          <button type="button" className="btn-primary" onClick={exportPdf}><Icon name="download" className="h-4 w-4" />Export PDF</button>
        </div>
      </header>

      <div className="flex flex-wrap gap-4 text-xs font-semibold text-slate-600">
        {Object.entries(STATUS).map(([key, s]) => (
          <span key={key} className="inline-flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-full ${s.dot}`} />{s.label}</span>
        ))}
      </div>

      {roadmap.meta.dropped?.length > 0 && (
        <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900">These branch courses did not fit in four semesters and were left out: {roadmap.meta.dropped.join(', ')}. You can add them from the catalog later.</p>
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {roadmap.semesters.map((s) => (
          <section key={s.index} className="rounded-xl bg-white/60 p-3 ring-1 ring-slate-200">
            <div className="mb-3 px-1">
              <div className="flex items-baseline justify-between">
                <h2 className="text-lg font-bold">Semester {s.semesterNo}</h2>
                <span className="text-xs font-semibold text-slate-500">{s.credits} credits</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200">
                <div className="h-full rounded-full bg-sprout-500 transition-all duration-1000" style={{ width: `${s.pct}%` }} />
              </div>
              <p className="mt-1 text-xs text-slate-500">{s.completedCount} of {s.courses.length} done · {s.pct}%</p>
            </div>
            <div className="space-y-3">{s.courses.map((id) => <RoadmapCard key={id} id={id} />)}</div>
          </section>
        ))}
      </div>
    </div>
  );
}
