const express = require('express');
const fs = require('fs');
const path = require('path');
const { initDb } = require('./db');
const buildRouter = require('./routes');

const PORT = process.env.PORT || 4000;
const db = initDb();
const app = express();

app.use(express.json());
app.use('/api', buildRouter(db));

// After `npm run build` in client/, the API server also serves the UI.
const dist = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use('/api', (req, res) => res.status(404).json({ error: 'Unknown API route.' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Something went wrong on the server.' : err.message, ...(err.unmet ? { unmet: err.unmet } : {}) });
});

app.listen(PORT, () => console.log(`LearnLoop API running on http://localhost:${PORT}`));
