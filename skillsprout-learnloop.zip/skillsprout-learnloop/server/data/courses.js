// Course catalogue. Prerequisite chains are kept shallow on purpose so every
// career pathway can finish inside four semesters.
const C = (id, title, credits, difficulty, category, prereqs, description, pathways = []) =>
  ({ id, title, credits, difficulty, category, prereqs, description, pathways });

const courses = [
  // first-year foundation
  C('MA101', 'Engineering Mathematics I', 4, 'Medium', 'Math', [], 'Limits, differentiation, integration and series, with an eye on how engineers actually use them.'),
  C('PH101', 'Engineering Physics', 3, 'Easy', 'Science', [], 'Mechanics, waves, optics and a first look at modern physics for engineers.'),
  C('CH101', 'Engineering Chemistry', 3, 'Easy', 'Science', [], 'Materials, electrochemistry and corrosion, plus the chemistry behind batteries and polymers.'),
  C('CS101', 'Programming Fundamentals', 4, 'Easy', 'Programming', [], 'Variables, control flow, functions, arrays and debugging, taught in C and Python.'),
  C('EG101', 'Engineering Graphics and Design', 2, 'Easy', 'Mechanical', [], 'Orthographic projection, sectioning and an introduction to CAD drafting.'),
  C('HS101', 'Technical Communication', 2, 'Easy', 'Humanities', [], 'Writing reports, reading documentation and presenting technical work clearly.'),
  C('EE101', 'Basic Electrical Engineering', 3, 'Medium', 'Electronics', [], 'DC and AC circuits, network theorems, transformers and basic machines.'),
  C('MA102', 'Engineering Mathematics II', 4, 'Medium', 'Math', ['MA101'], 'Multivariable calculus, differential equations and Laplace transforms.'),
  C('MA103', 'Discrete Mathematics', 3, 'Medium', 'Math', ['MA101'], 'Logic, sets, relations, graphs and counting techniques used throughout computer science.'),
  C('MA201', 'Probability and Statistics', 3, 'Medium', 'Math', ['MA101'], 'Random variables, distributions, estimation and hypothesis testing.'),
  C('MA202', 'Linear Algebra', 3, 'Medium', 'Math', ['MA101'], 'Vector spaces, eigenvalues and matrix decompositions with applications to data.'),
  C('ME101', 'Engineering Mechanics', 3, 'Medium', 'Mechanical', ['MA101'], 'Statics and dynamics of particles and rigid bodies.'),
  C('CS102', 'Object-Oriented Programming', 4, 'Medium', 'Programming', ['CS101'], 'Classes, inheritance, polymorphism and design basics using Java.'),

  // computer science core
  C('CS201', 'Data Structures', 4, 'Hard', 'Programming', ['CS102', 'MA103'], 'Lists, trees, heaps, hash tables and graphs, with complexity analysis.'),
  C('CS202', 'Digital Logic Design', 3, 'Medium', 'Electronics', ['EE101'], 'Boolean algebra, combinational and sequential circuits, finite state machines.'),
  C('CS203', 'Database Management Systems', 3, 'Medium', 'Systems', ['CS102'], 'Relational modelling, SQL, normalisation, transactions and indexing.', ['fullstack', 'cloud']),
  C('CS204', 'Computer Organization', 3, 'Medium', 'Systems', ['CS202'], 'Instruction sets, datapaths, pipelining, memory hierarchy and I/O.'),
  C('CS205', 'Algorithm Design and Analysis', 4, 'Hard', 'Programming', ['CS201'], 'Divide and conquer, greedy methods, dynamic programming and NP-completeness.'),
  C('CS206', 'Operating Systems', 4, 'Hard', 'Systems', ['CS201', 'CS204'], 'Processes, scheduling, memory management, file systems and concurrency.'),
  C('CS207', 'Computer Networks', 3, 'Medium', 'Systems', ['CS101'], 'Layered protocols, TCP/IP, routing, DNS and HTTP from the socket up.', ['cyber', 'cloud']),
  C('CS208', 'Software Engineering', 3, 'Medium', 'Programming', ['CS102'], 'Requirements, version control, testing, code review and agile delivery.', ['fullstack', 'cloud']),
  C('CS209', 'Theory of Computation', 3, 'Hard', 'Math', ['MA103'], 'Automata, formal languages, decidability and complexity classes.'),

  // full-stack web
  C('WD201', 'Web Development Fundamentals', 3, 'Easy', 'Web', ['CS101'], 'HTML, CSS, responsive layout and vanilla JavaScript in the browser.', ['fullstack']),
  C('WD202', 'Frontend Development with React', 3, 'Medium', 'Web', ['WD201', 'CS102'], 'Components, state, hooks, routing and talking to APIs.', ['fullstack']),
  C('WD203', 'Backend Development with Node.js', 3, 'Medium', 'Web', ['WD201', 'CS102'], 'Express, REST design, middleware, validation and persistence.', ['fullstack', 'cloud']),
  C('WD301', 'Full-Stack Application Development', 4, 'Hard', 'Web', ['WD202', 'WD203', 'CS203'], 'Build and deploy a complete product: UI, API, database and tests.', ['fullstack']),
  C('WD302', 'Web Security and Authentication', 3, 'Hard', 'Security', ['WD203'], 'Sessions, tokens, OWASP top ten, CSRF, XSS and secure deployment.', ['fullstack']),

  // AI and data
  C('AI201', 'Python for Data Science', 3, 'Easy', 'AI', ['CS101'], 'NumPy, pandas and notebooks for cleaning and exploring real datasets.', ['aiml']),
  C('AI301', 'Machine Learning Foundations', 4, 'Hard', 'AI', ['AI201', 'MA201', 'MA202'], 'Regression, classification, trees, clustering and model evaluation.', ['aiml']),
  C('AI302', 'Deep Learning', 4, 'Hard', 'AI', ['AI301'], 'Neural networks, CNNs, optimisation and training in practice.', ['aiml']),
  C('AI303', 'Natural Language Processing', 3, 'Hard', 'AI', ['AI301'], 'Tokenisation, embeddings, sequence models and transformer basics.', ['aiml']),
  C('DS301', 'Data Visualization and Analytics', 3, 'Medium', 'AI', ['AI201', 'MA201'], 'Telling honest stories with data using charts and dashboards.', ['aiml']),

  // cybersecurity
  C('CY201', 'Introduction to Cybersecurity', 3, 'Easy', 'Security', ['CS101'], 'Threat models, malware types, access control and security hygiene.', ['cyber']),
  C('CY301', 'Network Security', 3, 'Hard', 'Security', ['CS207', 'CY201'], 'Firewalls, VPNs, intrusion detection and secure protocol design.', ['cyber']),
  C('CY302', 'Cryptography', 3, 'Hard', 'Security', ['MA103', 'CY201'], 'Symmetric and public-key schemes, hashing, signatures and key exchange.', ['cyber']),
  C('CY303', 'Ethical Hacking and Penetration Testing', 3, 'Hard', 'Security', ['CY301'], 'Reconnaissance, lab exploitation and writing a responsible disclosure report.', ['cyber']),

  // embedded and IoT
  C('EC201', 'Analog and Digital Electronics', 4, 'Medium', 'Electronics', ['EE101'], 'Diodes, transistors, op-amps and logic families.', ['embedded']),
  C('EC202', 'Microcontrollers and Embedded C', 3, 'Medium', 'Electronics', ['CS101', 'EC201'], 'GPIO, timers, interrupts and serial protocols on ARM-based boards.', ['embedded']),
  C('EC203', 'Signals and Systems', 4, 'Hard', 'Electronics', ['MA102'], 'Continuous and discrete signals, convolution, Fourier and Z transforms.'),
  C('EC301', 'IoT Systems Design', 3, 'Medium', 'Electronics', ['EC202'], 'Sensors, wireless links, MQTT and cloud dashboards for connected devices.', ['embedded']),
  C('EC302', 'Real-Time Operating Systems', 3, 'Hard', 'Systems', ['EC202'], 'Task scheduling, priorities, synchronisation and timing guarantees.', ['embedded']),

  // cloud and devops
  C('CL301', 'Cloud Computing Fundamentals', 3, 'Medium', 'Systems', ['CS207'], 'Virtualisation, storage, networking and the major service models.', ['cloud']),
  C('CL302', 'DevOps and CI/CD', 3, 'Medium', 'Systems', ['CL301', 'CS208'], 'Pipelines, infrastructure as code, monitoring and release strategies.', ['cloud']),
  C('CL303', 'Containers and Microservices', 3, 'Hard', 'Systems', ['CL301', 'WD203'], 'Docker, orchestration basics and splitting a service safely.', ['cloud']),

  // electrical and mechanical extras
  C('EE201', 'Circuit Analysis', 4, 'Medium', 'Electronics', ['EE101', 'MA102'], 'Transient response, resonance, two-port networks and phasor methods.'),
  C('EE202', 'Electrical Machines', 3, 'Hard', 'Electronics', ['EE201'], 'DC machines, induction motors, synchronous machines and drives.'),
  C('ME201', 'Thermodynamics', 3, 'Medium', 'Mechanical', ['PH101', 'MA101'], 'Laws of thermodynamics, cycles, entropy and heat engines.'),
  C('ME202', 'Strength of Materials', 3, 'Medium', 'Mechanical', ['ME101'], 'Stress, strain, bending, torsion and beam deflection.'),
];

const branches = {
  CSE: { name: 'Computer Science and Engineering', core: ['MA101','PH101','CS101','EG101','HS101','EE101','MA102','CS102','MA103','CS201','CS202','CS203','CS204','CS205','CS206','MA201','CS207','CS208'] },
  IT: { name: 'Information Technology', core: ['MA101','PH101','CS101','EG101','HS101','EE101','MA102','CS102','MA103','CS201','CS203','CS205','CS207','CS208','MA201'] },
  ECE: { name: 'Electronics and Communication', core: ['MA101','PH101','CS101','EG101','HS101','EE101','MA102','CS102','CS202','CS204','EC201','EC202','EC203','MA201'] },
  EEE: { name: 'Electrical and Electronics', core: ['MA101','PH101','CS101','EG101','HS101','EE101','MA102','CS102','EE201','EE202','EC201','EC203','MA201'] },
  MECH: { name: 'Mechanical Engineering', core: ['MA101','PH101','CH101','CS101','EG101','HS101','EE101','MA102','CS102','ME101','ME201','ME202','MA201'] },
};

const pathways = {
  fullstack: { name: 'Full-Stack Web', blurb: 'React front ends, Node back ends and the databases behind them.' },
  aiml: { name: 'AI and Machine Learning', blurb: 'Data, statistics and models, from regression to deep learning.' },
  cyber: { name: 'Cybersecurity', blurb: 'Networks, cryptography and the habit of thinking like an attacker.' },
  embedded: { name: 'Embedded and IoT', blurb: 'Microcontrollers, sensors and real-time software on small devices.' },
  cloud: { name: 'Cloud and DevOps', blurb: 'Deploying, scaling and operating software reliably.' },
};

const experienceLevels = {
  none: { label: 'Brand new', cap: 20 },
  beginner: { label: 'Beginner', cap: 21 },
  intermediate: { label: 'Intermediate', cap: 22 },
  advanced: { label: 'Advanced', cap: 24 },
};

const studyGroups = [
  ['g1', 'CS101 Late Night Debuggers', 'CS101', null, 'Mon and Wed, 8:00 PM', 'Online', 8, 5, 'Work through weekly lab problems together and trade debugging tricks.'],
  ['g2', 'Foundations Math Circle', 'MA101', null, 'Tue and Thu, 5:30 PM', 'Library room 2', 6, 4, 'Problem sets, past papers and plenty of whiteboard time.'],
  ['g3', 'OOP Pair Programmers', 'CS102', null, 'Sat, 11:00 AM', 'Online', 8, 3, 'Pair up on class design exercises and review each other\'s code.'],
  ['g4', 'Data Structures Grind', 'CS201', null, 'Sun, 4:00 PM', 'Online', 10, 7, 'One topic a week, then a timed problem round.'],
  ['g5', 'Web Builders Club', 'WD201', 'fullstack', 'Fri, 6:00 PM', 'Lab 3', 8, 6, 'Show what you built this week and get feedback on layout and code.'],
  ['g6', 'React Study Squad', 'WD202', 'fullstack', 'Wed, 7:30 PM', 'Online', 8, 4, 'Component design, state bugs and small shared projects.'],
  ['g7', 'Node and APIs Workshop', 'WD203', 'fullstack', 'Thu, 7:00 PM', 'Online', 8, 3, 'Build REST endpoints together and test them with real clients.'],
  ['g8', 'Python for Data Crew', 'AI201', 'aiml', 'Sat, 3:00 PM', 'Online', 10, 6, 'Notebook walkthroughs and small Kaggle-style challenges.'],
  ['g9', 'ML Reading Group', 'AI301', 'aiml', 'Sun, 6:00 PM', 'Online', 10, 5, 'Read one chapter, implement one algorithm, compare notes.'],
  ['g10', 'Security Basics Lab', 'CY201', 'cyber', 'Tue, 8:00 PM', 'Online', 8, 4, 'Capture-the-flag warm-ups for beginners.'],
  ['g11', 'Breadboard Club', 'EC202', 'embedded', 'Sat, 10:00 AM', 'Electronics lab', 6, 3, 'Bring a board, wire something up and get it blinking.'],
  ['g12', 'Cloud Study Hall', 'CL301', 'cloud', 'Mon, 7:00 PM', 'Online', 8, 4, 'Walk through free-tier labs and compare deployment notes.'],
].map(([id, name, course_id, pathway, schedule, mode, seats, seed_members, description]) =>
  ({ id, name, course_id, pathway, schedule, mode, seats, seed_members, description }));

module.exports = { courses, branches, pathways, experienceLevels, studyGroups };
