const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const { courses, studyGroups } = require('./data/courses');
const { kahn } = require('./lib/graph');

const schema = `
CREATE TABLE IF NOT EXISTS courses (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  credits INTEGER NOT NULL,
  difficulty TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  pathways TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS prerequisites (
  course_id TEXT NOT NULL REFERENCES courses(id),
  prereq_id TEXT NOT NULL REFERENCES courses(id),
  PRIMARY KEY (course_id, prereq_id)
);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  branch TEXT,
  semester INTEGER,
  experience TEXT,
  pathway TEXT,
  profile_done INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS enrollments (
  student_id INTEGER NOT NULL REFERENCES students(id),
  course_id TEXT NOT NULL REFERENCES courses(id),
  status TEXT NOT NULL CHECK (status IN ('enrolled','completed')),
  enrolled_at TEXT NOT NULL,
  completed_at TEXT,
  PRIMARY KEY (student_id, course_id)
);
CREATE TABLE IF NOT EXISTS module_progress (
  student_id INTEGER NOT NULL REFERENCES students(id),
  course_id TEXT NOT NULL REFERENCES courses(id),
  module_no INTEGER NOT NULL,
  done_at TEXT NOT NULL,
  PRIMARY KEY (student_id, course_id, module_no)
);
CREATE TABLE IF NOT EXISTS roadmaps (
  student_id INTEGER PRIMARY KEY REFERENCES students(id),
  data TEXT NOT NULL,
  generated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS study_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  course_id TEXT NOT NULL REFERENCES courses(id),
  pathway TEXT,
  schedule TEXT NOT NULL,
  mode TEXT NOT NULL,
  seats INTEGER NOT NULL,
  seed_members INTEGER NOT NULL,
  description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS group_members (
  student_id INTEGER NOT NULL REFERENCES students(id),
  group_id TEXT NOT NULL REFERENCES study_groups(id),
  PRIMARY KEY (student_id, group_id)
);
`;

function initDb(file) {
  const target = file || process.env.DB_FILE || path.join(__dirname, 'data', 'learnloop.db');
  if (target !== ':memory:') fs.mkdirSync(path.dirname(target), { recursive: true });
  const db = new Database(target);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(schema);

  const count = db.prepare('SELECT COUNT(*) AS n FROM courses').get().n;
  if (count === 0) {
    const addCourse = db.prepare('INSERT INTO courses (id,title,credits,difficulty,category,description,pathways) VALUES (?,?,?,?,?,?,?)');
    const addEdge = db.prepare('INSERT INTO prerequisites (course_id, prereq_id) VALUES (?,?)');
    const addGroup = db.prepare('INSERT INTO study_groups (id,name,course_id,pathway,schedule,mode,seats,seed_members,description) VALUES (?,?,?,?,?,?,?,?,?)');
    db.transaction(() => {
      courses.forEach((c) => addCourse.run(c.id, c.title, c.credits, c.difficulty, c.category, c.description, c.pathways.join(',')));
      courses.forEach((c) => c.prereqs.forEach((p) => addEdge.run(c.id, p)));
      studyGroups.forEach((g) => addGroup.run(g.id, g.name, g.course_id, g.pathway, g.schedule, g.mode, g.seats, g.seed_members, g.description));
    })();
  }

  // Refuse to start with a circular catalogue.
  const map = {};
  db.prepare('SELECT id FROM courses').all().forEach((r) => { map[r.id] = []; });
  db.prepare('SELECT course_id, prereq_id FROM prerequisites').all().forEach((r) => map[r.course_id].push(r.prereq_id));
  const check = kahn(Object.keys(map), map);
  if (check.hasCycle) throw new Error('Course catalogue has a circular prerequisite: ' + check.cycle.join(' -> '));
  return db;
}

module.exports = { initDb };
