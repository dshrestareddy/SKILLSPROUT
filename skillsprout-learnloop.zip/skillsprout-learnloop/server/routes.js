const express = require('express');
const { createService } = require('./lib/service');
const { branches, pathways, experienceLevels } = require('./data/courses');

module.exports = function buildRouter(db) {
  const svc = createService(db);
  const router = express.Router();
  const wrap = (fn) => (req, res, next) => {
    try { res.json(fn(req)); } catch (err) { next(err); }
  };

  router.get('/health', wrap(() => ({ ok: true, courses: svc.courses.length })));

  router.get('/meta', wrap(() => ({
    branches: Object.entries(branches).map(([id, b]) => ({ id, name: b.name })),
    pathways: Object.entries(pathways).map(([id, p]) => ({ id, ...p })),
    experience: Object.entries(experienceLevels).map(([id, e]) => ({ id, label: e.label })),
  })));

  router.post('/auth/login', wrap((req) => svc.login(req.body.name, req.body.email)));

  router.get('/students/:id/state', wrap((req) => svc.buildState(req.params.id)));
  router.put('/students/:id/profile', wrap((req) => svc.saveProfile(req.params.id, req.body)));
  router.post('/students/:id/roadmap', wrap((req) => svc.makeRoadmap(req.params.id)));
  router.post('/students/:id/enroll', wrap((req) => svc.enroll(req.params.id, req.body.courseId)));
  router.delete('/students/:id/enroll/:courseId', wrap((req) => svc.drop(req.params.id, req.params.courseId)));
  router.put('/students/:id/modules', wrap((req) => svc.setModule(req.params.id, req.body.courseId, req.body.moduleNo, req.body.done)));
  router.delete('/students/:id/progress', wrap((req) => svc.resetProgress(req.params.id)));
  router.get('/students/:id/study-estimate', wrap((req) => svc.studyEstimate(req.params.id)));
  router.get('/students/:id/groups', wrap((req) => ({ groups: svc.groupsFor(req.params.id) })));
  router.post('/students/:id/groups/:gid/join', wrap((req) => ({ groups: svc.joinGroup(req.params.id, req.params.gid) })));
  router.delete('/students/:id/groups/:gid/join', wrap((req) => ({ groups: svc.leaveGroup(req.params.id, req.params.gid) })));

  router.get('/courses', wrap((req) => ({ courses: svc.searchCourses(req.query) })));
  router.get('/courses/:id', wrap((req) => {
    const c = svc.courseMap[req.params.id];
    if (!c) throw Object.assign(new Error('That course does not exist.'), { status: 404 });
    return c;
  }));
  router.get('/graph', wrap(() => svc.graph()));
  router.post('/graph/check-edge', wrap((req) => svc.checkEdge(req.body.course, req.body.prereq)));

  return router;
};
