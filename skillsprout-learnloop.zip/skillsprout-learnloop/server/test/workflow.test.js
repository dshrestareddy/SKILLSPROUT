// End-to-end check of the demo workflow. Starts the real server, drives the
// REST API, then restarts the server on the same database file to prove that
// progress survives. Run with: npm test (from the server folder)
const { spawn } = require('child_process');
const assert = require('assert');
const path = require('path');
const os = require('os');
const fs = require('fs');

const PORT = 4599;
const BASE = `http://localhost:${PORT}/api`;
const DB_FILE = path.join(os.tmpdir(), `learnloop-test-${Date.now()}.db`);
let child;
let passed = 0;

function startServer() {
  child = spawn(process.execPath, ['--no-warnings', 'index.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT: String(PORT), DB_FILE },
    stdio: 'ignore',
  });
}
const stopServer = () => new Promise((resolve) => { child.once('exit', resolve); child.kill(); });

async function waitForServer() {
  for (let i = 0; i < 50; i++) {
    try { const r = await fetch(`${BASE}/health`); if (r.ok) return; } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('Server did not start');
}

async function call(method, url, body) {
  const res = await fetch(BASE + url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, data: await res.json() };
}

async function step(name, fn) {
  try { await fn(); passed += 1; console.log(`  ok   ${name}`); }
  catch (err) { console.log(`  FAIL ${name}\n       ${err.message}`); process.exitCode = 1; }
}

(async () => {
  startServer();
  await waitForServer();
  console.log('LearnLoop workflow test');
  let id;

  await step('rejects an invalid email', async () => {
    const r = await call('POST', '/auth/login', { name: 'Aarav Menon', email: 'not-an-email' });
    assert.strictEqual(r.status, 400);
  });

  await step('signs in a first-year student', async () => {
    const r = await call('POST', '/auth/login', { name: 'Aarav Menon', email: 'demo@skillsprout.dev' });
    assert.strictEqual(r.status, 200);
    id = r.data.student.id;
    assert.strictEqual(r.data.student.profileDone, false);
  });

  await step('rejects a bad diagnostic', async () => {
    const r = await call('PUT', `/students/${id}/profile`, { branch: 'CSE', semester: 12, experience: 'beginner', pathway: 'fullstack' });
    assert.strictEqual(r.status, 400);
  });

  await step('saves the diagnostic (CSE, semester 1, Full-Stack Web)', async () => {
    const r = await call('PUT', `/students/${id}/profile`, { branch: 'CSE', semester: 1, experience: 'beginner', pathway: 'fullstack' });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.data.student.pathway, 'fullstack');
  });

  await step('generates a four-semester roadmap that respects prerequisites', async () => {
    const r = await call('POST', `/students/${id}/roadmap`);
    assert.strictEqual(r.status, 200);
    const sems = r.data.roadmap.semesters;
    assert.strictEqual(sems.length, 4);
    const where = {};
    sems.forEach((s) => s.courses.forEach((c) => { where[c] = s.index; }));
    assert.ok(where.CS101 === 1 && where.WD301, 'CS101 in semester 1 and WD301 planned');
    const all = (await call('GET', '/courses')).data.courses;
    all.filter((c) => where[c.id]).forEach((c) => c.prereqs.forEach((p) => {
      assert.ok(where[p] < where[c.id], `${p} must come before ${c.id}`);
    }));
  });

  await step('blocks enrolling in CS102 before CS101 is done', async () => {
    const r = await call('POST', `/students/${id}/enroll`, { courseId: 'CS102' });
    assert.strictEqual(r.status, 409);
    assert.ok(/CS101/.test(r.data.error));
  });

  await step('enrolls in CS101', async () => {
    const r = await call('POST', `/students/${id}/enroll`, { courseId: 'CS101' });
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.data.courseState.CS101.status, 'enrolled');
  });

  await step('completing Module 1 shows 25% progress', async () => {
    const r = await call('PUT', `/students/${id}/modules`, { courseId: 'CS101', moduleNo: 1, done: true });
    assert.strictEqual(r.data.courseState.CS101.progress, 25);
  });

  await step('progress survives a full server restart', async () => {
    await stopServer();
    startServer();
    await waitForServer();
    const r = await call('GET', `/students/${id}/state`);
    assert.strictEqual(r.data.courseState.CS101.progress, 25);
    assert.strictEqual(r.data.courseState.CS101.status, 'enrolled');
    assert.ok(r.data.roadmap, 'roadmap is still stored');
  });

  await step('finishing all modules completes CS101 and unlocks CS102', async () => {
    let r;
    for (const n of [2, 3, 4]) r = await call('PUT', `/students/${id}/modules`, { courseId: 'CS101', moduleNo: n, done: true });
    assert.strictEqual(r.data.courseState.CS101.status, 'completed');
    assert.strictEqual(r.data.courseState.CS102.status, 'unlocked');
    assert.strictEqual(r.data.stats.completedCredits, 4);
  });

  await step('CS101 cannot be reopened while CS102 depends on it', async () => {
    await call('POST', `/students/${id}/enroll`, { courseId: 'CS102' });
    const r = await call('PUT', `/students/${id}/modules`, { courseId: 'CS101', moduleNo: 4, done: false });
    assert.strictEqual(r.status, 409);
    const drop = await call('DELETE', `/students/${id}/enroll/CS102`);
    assert.strictEqual(drop.status, 200);
    const reopen = await call('PUT', `/students/${id}/modules`, { courseId: 'CS101', moduleNo: 4, done: false });
    assert.strictEqual(reopen.data.courseState.CS101.status, 'enrolled');
  });

  await step('study-hours estimate reflects enrolled courses', async () => {
    const r = await call('GET', `/students/${id}/study-estimate`);
    assert.ok(r.data.total > 0 && r.data.items.length === 1);
  });

  await step('study groups: recommend, join, leave', async () => {
    const list = (await call('GET', `/students/${id}/groups`)).data.groups;
    assert.strictEqual(list[0].courseId, 'CS101', 'CS101 group ranks first');
    const joined = (await call('POST', `/students/${id}/groups/g1/join`)).data.groups.find((g) => g.id === 'g1');
    assert.ok(joined.joined);
    const dup = await call('POST', `/students/${id}/groups/g1/join`);
    assert.strictEqual(dup.status, 409);
    const left = (await call('DELETE', `/students/${id}/groups/g1/join`)).data.groups.find((g) => g.id === 'g1');
    assert.ok(!left.joined);
  });

  await step('catalogue search and filters work', async () => {
    const byCode = (await call('GET', '/courses?search=cs101')).data.courses;
    assert.strictEqual(byCode.length, 1);
    const hard4 = (await call('GET', '/courses?credits=4&difficulty=Hard')).data.courses;
    assert.ok(hard4.length > 0 && hard4.every((c) => c.credits === 4 && c.difficulty === 'Hard'));
  });

  await step('dependency graph is acyclic and cycle checks work', async () => {
    const g = (await call('GET', '/graph')).data;
    assert.strictEqual(g.validation.hasCycle, false);
    assert.ok(g.nodes.length >= 40, 'at least 40 courses');
    const bad = (await call('POST', '/graph/check-edge', { course: 'CS101', prereq: 'CS201' })).data;
    assert.strictEqual(bad.safe, false);
    assert.ok(bad.cycle.length >= 3);
    const ok = (await call('POST', '/graph/check-edge', { course: 'CS205', prereq: 'MA202' })).data;
    assert.strictEqual(ok.safe, true);
  });

  await step('reset clears progress but keeps the roadmap', async () => {
    const r = await call('DELETE', `/students/${id}/progress`);
    assert.strictEqual(r.data.courseState.CS101.status, 'unlocked');
    assert.ok(r.data.roadmap);
  });

  await stopServer();
  for (const ext of ['', '-wal', '-shm']) fs.rmSync(DB_FILE + ext, { force: true });
  console.log(`\n${passed} checks passed${process.exitCode ? ', some failed' : ''}`);
})();
